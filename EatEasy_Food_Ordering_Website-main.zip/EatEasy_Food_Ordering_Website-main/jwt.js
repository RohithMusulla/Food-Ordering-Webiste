const crypto = require('crypto');

// Sample payload
const payload = {
  user_id: 123456,
  username: 'example_user',
  email: 'user@example.com'
};

// Secret key to sign the token
const secretKey = 'your_secret_key_here';

// Encode the payload
const headerEncoded = Buffer.from(JSON.stringify({ typ: 'JWT', alg: 'HS256' })).toString('base64');
const payloadEncoded = Buffer.from(JSON.stringify(payload)).toString('base64');

// Create the signature
const signature = crypto.createHmac('sha256', secretKey)
                          .update(headerEncoded + '.' + payloadEncoded)
                          .digest('base64')
                          .replace(/=/g, '');

// JWT token
const token = `${headerEncoded}.${payloadEncoded}.${signature}`;

console.log('Generated JWT:', token);
